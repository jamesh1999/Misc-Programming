<?php

if(!isset($_SESSION)){
    session_start;   
}

if($_SESSION['last_request'] > time() - 5 and $_SESSION['request_count'] > 4)
{
    ++$_SESSION['request_count'];
    
    $fp = fopen('blacklist.txt', 'a+');
    if($fp)
    {
        fwrite($fp, $_SERVER['REMOTE_ADDR'] . " b\n" . $_SERVER['HTTP_X_FORWARDED_FOR'] . " b\n");
        fclose($fp);
    }
    
    exit();
}
else
{
       $_SESSION['request_count'] = 0;
}

$_SESSION['last_request'] = time();