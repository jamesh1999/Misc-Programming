<?php
$server = "mysql.hostinger.co.uk";
$username = "u215184977_user";
$password = "oRy$@9sh1Mav^KOiPa";
$database = "u215184977_revie";
?>